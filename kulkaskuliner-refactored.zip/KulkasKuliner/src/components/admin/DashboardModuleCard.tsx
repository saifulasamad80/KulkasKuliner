"use client";

type DashboardModuleCardProps = {
  icon: string;
  title: string;
  description: string;
  accentClassName: string;
  onClick: () => void;
};

/** One clickable summary card on the admin dashboard's module menu. */
export default function DashboardModuleCard({ icon, title, description, accentClassName, onClick }: DashboardModuleCardProps) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="group text-left bg-white p-6 rounded-xl shadow-sm border border-gray-200 hover:shadow-md hover:border-gray-300 transition-all focus:outline-none focus:ring-2 focus:ring-blue-400"
    >
      <div className={`w-12 h-12 rounded-lg flex items-center justify-center text-2xl mb-4 ${accentClassName}`}>
        <span aria-hidden="true">{icon}</span>
      </div>
      <h3 className="text-lg font-bold text-gray-900 mb-1">{title}</h3>
      <p className="text-sm text-gray-500 leading-snug">{description}</p>
      <span className="mt-4 flex items-center gap-1 text-xs font-bold text-blue-600 group-hover:gap-2 transition-all">
        Buka modul <span aria-hidden="true">→</span>
      </span>
    </button>
  );
}
